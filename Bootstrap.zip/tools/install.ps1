#region Configuration Container
Configuration ConfigMgrHealthCheck
	{
	[Parameter(Mandatory=$True)]
	[string]$CMInstallArguments
	Package ConfigMgrClient
	{
	Ensure = "Present"
	Path = "$env:WINDIR\Temp\Azure\smsClient\ccmsetup.exe"
	Arguments = $CMInstallArguments
	Name = "Configuration Manager Client"
	Logpath = "$env:WINDIR\Logs"
	ProductId = "D6804B3A-BFEC-4AB4-BFA5-FD9BECC80630"
	}
	Service BITS
	{
	Name = "BITS"
	StartupType = "Automatic"
	State = "Running"
	}
	Service winmgmt
	{
	Name = "winmgmt"
	StartupType = "Automatic"
	State = "Running"
	}
	Service wuauserv
	{
	Name = "wuauserv"
	StartupType = "Automatic"
	State = "Running"
	}
	Service lanmanserver
	{
	Name = "lanmanserver"
	StartupType = "Automatic"
	State = "Running"
	}
	Service RpcSs
	{
	Name = "RpcSs"
	StartupType = "Automatic"
	State = "Running"
	}
	Service ccmexec
	{
	Name = "ccmexec"
	StartupType = "Automatic"
	State = "Running"
	}
	Service lanmanworkstation
	{
	Name = "lanmanworkstation"
	StartupType = "Automatic"
	State = "Running"
	}
	Service CryptSvc
	{
	Name = "CryptSvc"
	StartupType = "Automatic"
	State = "Running"
	}
	Service ProtectedStorage
	{
	Name = "ProtectedStorage"
	StartupType = "Automatic"
	State = "Running"
	}
	Service PolicyAgent
	{
	Name = "PolicyAgent"
	StartupType = "Automatic"
	State = "Running"
	}
	Service RemoteRegistry
	{
	Name = "RemoteRegistry"
	StartupType = "Automatic"
	State = "Running"
	}
	Registry EnableDCOM
	{
	Ensure = "Present"
	Key = "HKEY_Local_Machine\SOFTWARE\Microsoft\Ole"
	ValueName = "EnableDCOM"
	ValueData = "Y"
	Force = $true
	}
}
#endregion

#region Import Pfx Certificate
$mypwd = ConvertTo-SecureString -String "P@$$w0rd1" -Force AsPlainText
Import-PfxCertificate FilePath $env:WINDIR\Temp\Azure\Cert\sccm.pfx cert:\localMachine\my -Password $mypwd
#endregion

#region Install the SCCM Client
ConfigMgrHealthCheck -CMInstallArguments "/native:FALLBACK /mp:mp.osd.tips SMSSLP=mp.osd.tips SMSSITECODE=PS1 CCMFIRSTCERT=1" -OutputPath .\
#Start-DscConfiguration -path .\ -verbose
#endregion

# Sleep for 5 minutes
Start-Sleep 300

#region Trigger the SCCM Client
$strComputer = "localhost"
$smscli = [wmiclass] "\\$strComputer\root\ccm:sms_client"
#Application Deployment Evaluation Cycle
$smscli.TriggerSchedule("{00000000-0000-0000-0000-000000000121}") | Out-Null
#Machine Policy Retrieval and Evaluation Cycle
$smscli.TriggerSchedule("{00000000-0000-0000-0000-000000000021}") | Out-Null
#Evaluate Machine Policy Assignments
$smscli.TriggerSchedule("{00000000-0000-0000-0000-000000000022}") | Out-Null
#endregion